package com.restapi.dynamiccontent.restapidynamiccontent;

import org.springframework.data.jpa.repository.JpaRepository;


public interface VideosRepository extends JpaRepository<Videos, Long> {
}
