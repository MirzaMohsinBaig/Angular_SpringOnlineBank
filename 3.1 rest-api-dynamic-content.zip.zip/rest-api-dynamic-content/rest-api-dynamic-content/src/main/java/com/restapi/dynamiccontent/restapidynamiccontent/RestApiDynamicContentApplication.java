package com.restapi.dynamiccontent.restapidynamiccontent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiDynamicContentApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiDynamicContentApplication.class, args);
	}
}
